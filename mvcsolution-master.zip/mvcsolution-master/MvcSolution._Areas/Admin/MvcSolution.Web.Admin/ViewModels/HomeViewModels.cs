﻿using MvcSolution.Web.ViewModels;

namespace MvcSolution.Web.Admin.ViewModels
{
    public class HomeIndexViewModel : LayoutViewModel
    {

    }
}
