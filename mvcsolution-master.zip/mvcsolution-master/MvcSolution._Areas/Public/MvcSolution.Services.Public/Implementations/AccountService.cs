﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MvcSolution.Data;
using MvcSolution;

namespace MvcSolution.Services.Public
{
    public class AccountService : ServiceBase, IAccountService
    {
        
        
        
    }
}
