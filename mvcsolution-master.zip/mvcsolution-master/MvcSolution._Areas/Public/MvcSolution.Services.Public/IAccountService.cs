﻿using System;
using MvcSolution.Data;
using MvcSolution;

namespace MvcSolution.Services.Public
{
    public interface IAccountService
    {
        
        
        
    }
}
