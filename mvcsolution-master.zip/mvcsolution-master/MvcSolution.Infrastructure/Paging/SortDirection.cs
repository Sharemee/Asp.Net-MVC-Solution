﻿namespace MvcSolution
{
    public enum SortDirection
    {
        None = 0,
        Asc = 1,
        Desc = 2
    }
}
