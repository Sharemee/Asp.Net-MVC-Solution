﻿using System.Drawing.Imaging;

namespace MvcSolution.Services
{
    public class ImageDataDto
    {
        public string OriginalPath { get; set; }
        public ImageFormat Format { get; set; }
    }
}
