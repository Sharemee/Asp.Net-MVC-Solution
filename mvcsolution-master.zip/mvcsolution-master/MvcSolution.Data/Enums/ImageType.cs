﻿namespace MvcSolution.Data
{
    public enum ImageType
    {
        Unknown = 0,
        UserAvatar = 189
    }
}
