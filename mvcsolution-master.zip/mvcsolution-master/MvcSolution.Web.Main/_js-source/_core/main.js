﻿var MvcSolution = {
    ajax: {
        
    },
    notification: {        
        
    },
    shell: {        
        
    },
    documentReady:{
        
    },
    utils: {
        
    },
    pages: {
        
    },
    ckey: null
};