﻿(function () {
    MvcSolution.app = {
        alert: function(msg) {
            alert(msg);
        }
    };
})();