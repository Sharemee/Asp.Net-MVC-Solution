﻿(function() {
    if (window.MvcSolution) {
        return;
    }
    window.MvcSolution = {
        guid: {
            empty: '00000000-0000-0000-0000-000000000000'
        }
    };
})();