﻿namespace MvcSolution.Web.Images
{
    public interface IImageParameterFixer
    {
        ImageParameter Fix(ImageParameter parameter);
    }
}
